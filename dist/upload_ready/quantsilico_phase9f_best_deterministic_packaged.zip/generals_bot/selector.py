"""Policy registry / selector."""

from __future__ import annotations

from typing import Any

from generals_bot.policies.heuristic_config import (
    AGGRESSIVE,
    CASTLE,
    DEATHTOUCH,
    DEFENSIVE,
)
from generals_bot.policies.heuristic_v0 import HeuristicV0Policy
from generals_bot.policies.heuristic_v1 import HeuristicV1Policy
from generals_bot.policies.heuristic_v2_ablations import (
    FLAGS,
    V1_REFERENCE,
    V2_9QD,
    V2F_BEST,
    V2F_RESTORED,
    create_ablation,
)
from generals_bot.policies.heuristic_v2_qualifier import HeuristicV2QualifierPolicy
from generals_bot.policies.heuristic_v2f_reference import HeuristicV2FReferencePolicy
from generals_bot.policies.official_expander import OfficialExpanderPolicy
from generals_bot.policies.official_hunter import OfficialHunterPolicy
from generals_bot.policies.pass_policy import PassPolicy
from generals_bot.policies.random_policy import RandomPolicy


def create_policy(name: str, **kwargs: Any) -> Any:
    key = name.strip().lower().replace("-", "_")
    if key in {"pass", "pass_bot", "pass_policy"}:
        return PassPolicy()
    if key in {"legal_random", "random", "random_policy"}:
        return RandomPolicy(seed=int(kwargs.get("seed", 0)))
    if key in {"official_expander", "expander", "official_expander_python"}:
        return OfficialExpanderPolicy()
    if key in {"official_hunter", "hunter"}:
        return OfficialHunterPolicy()
    if key in {"heuristic_v0", "heuristic0", "hv0"}:
        return HeuristicV0Policy()
    if key in {"heuristic_v1", "heuristic1", "hv1", V1_REFERENCE}:
        return HeuristicV1Policy()
    if key in {"heuristic_v2_qualifier", "heuristic_v2", "hv2", "v2_qualifier", V2_9QD}:
        return HeuristicV2QualifierPolicy()
    if key in {V2F_BEST, V2F_RESTORED, "heuristic_v2f_best_reference", "heuristic_v2f_restored"}:
        return HeuristicV2FReferencePolicy()
    if key in FLAGS:
        return create_ablation(key)
    if key in {"heuristic_aggressive", "aggressive"}:
        return HeuristicV1Policy(config=AGGRESSIVE)
    if key in {"heuristic_defensive", "defensive"}:
        return HeuristicV1Policy(config=DEFENSIVE)
    if key in {"heuristic_castle", "castle"}:
        return HeuristicV1Policy(config=CASTLE)
    if key in {"heuristic_deathtouch", "deathtouch"}:
        return HeuristicV1Policy(config=DEATHTOUCH)
    raise KeyError(f"unknown policy: {name}")


def list_policies() -> list[str]:
    return [
        "pass",
        "legal_random",
        "official_expander",
        "official_hunter",
        "heuristic_v0",
        "heuristic_v1",
        "heuristic_v1_reference",
        "heuristic_v2_qualifier",
        "heuristic_v2_9qd_latest",
        "heuristic_v2f_best_reference",
        "heuristic_v2f_restored",
        *sorted(FLAGS.keys()),
        "heuristic_aggressive",
        "heuristic_defensive",
        "heuristic_castle",
        "heuristic_deathtouch",
    ]
