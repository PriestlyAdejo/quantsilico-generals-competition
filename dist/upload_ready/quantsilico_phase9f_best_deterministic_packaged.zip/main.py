from generals_bot.agent import run_agent
from generals_bot.policies.heuristic_v2_ablations import create_ablation

def main():
    run_agent(create_ablation("heuristic_v2f_plus_planner_terminal_fix"), deterministic=True)

if __name__ == '__main__':
    main()
